using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class defaultBullet : BulletEntity
{
    defaultBullet(Vector3 dir)
    {
        direction = dir;
    }
}
